-- 1) Identifique e liste quantos valores diferentes est�o definidos para a coluna Situacao da tabela Produto 
-- (somente os distintos valores).

SELECT situacao
FROM Produto
GROUP BY Situacao 
ORDER BY situacao ASC

-- 2) Liste todos os clientes que tenham o LTDA no nome ou razao social.

SELECT Nome
FROM Cliente
WHERE nome LIKE '%LTDA%' Or razaoSocial LIKE '%LTDA%'

-- 3) Crie (insira) um novo registro na tabela de Produto, com as seguintes informa��es:
-- Nome: Galocha Maragato
-- Pre�o de custo: 35.67
-- Pre�o de venda: 77.95
-- Situa��o: A

INSERT INTO Produto (nome, precoCusto, precoVenda, situacao) VALUES ('Galacha Maragato', 35.67, 77.95, 'A')

-- 4) Identifique e liste os produtos que n�o tiveram nenhum pedido, considere os relacionamentos no modelo de 
-- dados, pois n�o h� relacionamento direto entre Produto e Pedido (ser� preciso relacionar PedidoItem).
-- Obs.: o produto criado anteriormente dever� ser listado.

SELECT pr.IDProduto, pr.Nome
FROM Produto pr
LEFT JOIN PedidoItem pe ON pe.IDProduto = pr.IDproduto
WHERE IDPedido IS NULL

-- 5) Identifique qual o estado (coluna UF da tabela Cidade) possu� o maior n�mero de clientes (tabela Cliente), 
-- liste tamb�m qual o Estado possu� o menor n�mero de clientes.
-- Dica: pode (n�o � obrigat�rio) ser utilizado subquery, e tamb�m UNION. (N�o est� pronta)

SELECT TOP 1 WITH TIES Ci.UF
FROM Cidade ci
JOIN Cliente cl ON cl.IDCidade = ci.IDCidade
GROUP BY UF
ORDER BY UF


-- 6) Liste o total de cidades (distintas) que possuem clientes que realizaram algum pedido.
-- Dica: ser� preciso relacionar Cidade com Cliente, e Cliente com Pedido. (N�o est� pronta)

SELECT ci.nome
FROM Cidade ci
JOIN Cliente cl ON ci.IDCidade = cl.IDCidade
GROUP BY ci.nome
ORDER BY ci.nome ASC



